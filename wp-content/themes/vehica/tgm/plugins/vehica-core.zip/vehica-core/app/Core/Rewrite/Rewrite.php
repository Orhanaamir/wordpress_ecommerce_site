<?php

namespace Vehica\Core\Rewrite;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Rewrite
 */
class Rewrite
{
    const NAME = 'vehica_name';
    const SINGULAR_NAME = 'vehica_singular_name';
    const REWRITE = 'vehica_rewrite';
}