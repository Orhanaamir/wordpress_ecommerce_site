"use strict"

jQuery(document).ready(function () {
    jQuery('.vehica-selectize').selectize();
});